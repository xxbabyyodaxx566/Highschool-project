import "./styles.css";
document.getElementById("app").innerHTML = `
<h1>Hello World!</h1>
<div>
  this is a web page im starting on my second day of highschool the coding languages include json html5 javascript and css
</div>
`;
//snowden
